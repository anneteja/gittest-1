# Working with Aws


Link to start with python SDK for AWS (boto3)
https://github.com/boto/boto3#quick-start

